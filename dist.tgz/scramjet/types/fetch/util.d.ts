import { ScramjetHeaders } from "../shared";
import { BareResponse } from "@mercuryworkshop/proxy-transports";
import { ScramjetFetchParsed } from ".";
/** Whether the response asks to be saved to disk rather than displayed. */
export declare function isAttachment(headers: {
    get(name: string): string | null;
}): boolean;
export declare function normalizeContentType(parsed: ScramjetFetchParsed, headers: ScramjetHeaders): void;
export declare function isRedirect(response: BareResponse): boolean;
export declare function isDocument(parsed: ScramjetFetchParsed): boolean;
export declare function createReferrerString(clientUrl: URL, resource: URL, policy: string | null): string;
