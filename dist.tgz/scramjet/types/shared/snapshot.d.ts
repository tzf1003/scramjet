export declare const String: StringConstructor;
export declare const String_fromCodePoint: (...codePoints: number[]) => string;
export declare const String_fromCharCode: (...codes: number[]) => string;
export declare const Function_prototype_toString: () => string;
export declare const String_startsWith: (str: string, searchString: string, position?: number) => boolean;
export declare const Number: NumberConstructor;
export declare const Number_parseInt: (string: string, radix?: number) => number;
export declare const Number_isSafeInteger: (number: unknown) => boolean;
export declare const Number_isFinite: (number: unknown) => boolean;
export declare const Object_keys: {
    (o: object): string[];
    (o: {}): string[];
};
export declare const Object_values: {
    <T>(o: {
        [s: string]: T;
    } | ArrayLike<T>): T[];
    (o: {}): any[];
};
export declare const Object_entries: {
    <T>(o: {
        [s: string]: T;
    } | ArrayLike<T>): [string, T][];
    (o: {}): [string, any][];
};
export declare const Object_hasOwn: (o: object, v: PropertyKey) => boolean;
export declare const Object_getOwnPropertyNames: (o: any) => string[];
export declare const Object_getOwnPropertyDescriptor: (o: any, p: PropertyKey) => PropertyDescriptor | undefined;
export declare const Object_getOwnPropertyDescriptors: <T>(o: T) => { [P in keyof T]: TypedPropertyDescriptor<T[P]>; } & {
    [x: string]: PropertyDescriptor;
};
export declare const Object_getOwnPropertySymbols: (o: any) => symbol[];
export declare const Object_defineProperty: <T>(o: T, p: PropertyKey, attributes: PropertyDescriptor & ThisType<any>) => T;
export declare const Object_defineProperties: <T>(o: T, properties: PropertyDescriptorMap & ThisType<any>) => T;
export declare const Object_setPrototypeOf: (o: any, proto: object | null) => any;
export declare const Object_getPrototypeOf: (o: any) => any;
export declare const Object_assign: {
    <T extends {}, U>(target: T, source: U): T & U;
    <T extends {}, U, V>(target: T, source1: U, source2: V): T & U & V;
    <T extends {}, U, V, W>(target: T, source1: U, source2: V, source3: W): T & U & V & W;
    (target: object, ...sources: any[]): any;
};
export declare const Reflect_get: typeof Reflect.get;
export declare const Reflect_set: typeof Reflect.set;
export declare const Reflect_has: typeof Reflect.has;
export declare const Reflect_ownKeys: typeof Reflect.ownKeys;
export declare const Reflect_construct: typeof Reflect.construct;
export declare const Reflect_apply: typeof Reflect.apply;
export declare const Array_from: {
    <T>(arrayLike: ArrayLike<T>): T[];
    <T, U>(arrayLike: ArrayLike<T>, mapfn: (v: T, k: number) => U, thisArg?: any): U[];
    <T>(iterable: Iterable<T> | ArrayLike<T>): T[];
    <T, U>(iterable: Iterable<T> | ArrayLike<T>, mapfn: (v: T, k: number) => U, thisArg?: any): U[];
};
export declare const Array_isArray: (arg: any) => arg is any[];
export declare const Array_of: <T>(...items: T[]) => T[];
export declare const JSON_parse: (text: string, reviver?: (this: any, key: string, value: any) => any) => any;
export declare const JSON_stringify: {
    (value: any, replacer?: (this: any, key: string, value: any) => any, space?: string | number): string;
    (value: any, replacer?: (number | string)[] | null, space?: string | number): string;
};
export declare const TextEncoder_encode: any;
export declare const TextDecoder_decode: (input?: AllowSharedBufferSource, options?: TextDecodeOptions) => string;
export declare const Performance_now: any;
export declare const btoa: typeof globalThis.btoa;
export declare const atob: typeof globalThis.atob;
export declare const URL_createObjectURL: any;
export declare const URL_revokeObjectURL: any;
export declare const Error: ErrorConstructor & {
    stackTraceLimit: number;
    prepareStackTrace?: (error: Error, stack: Array<{
        getFileName(): string | null;
    }>) => unknown;
};
export declare const TypeError: TypeErrorConstructor;
export declare const Date_now: () => number;
export declare const Intl_DateTimeFormat: Intl.DateTimeFormatConstructor;
export declare const Intl_getCanonicalLocales: typeof Intl.getCanonicalLocales;
export declare const Math_random: () => number;
export declare const Math_min: (...values: number[]) => number;
export declare const Math_max: (...values: number[]) => number;
export declare const Promise_all: any;
export declare const Promise_race: any;
export declare const Promise_resolve: any;
export declare const Promise_reject: any;
export declare const Promise_allSettled: any;
export declare const Promise_any: any;
export declare const Symbol_for: (key: string) => symbol;
export declare const WrappedBrand: unique symbol;
type WrappedInstance<T> = T extends object ? Wrapped<T> : T;
type ConstructorPrototype<T> = T extends {
    prototype: infer P;
} ? P : never;
type InstantiatePrototype<P, Params extends unknown[]> = Params extends [
    infer A,
    infer B
] ? P extends Map<any, any> ? Map<A, B> : P extends WeakMap<any, any> ? WeakMap<A & WeakKey, B> : P : Params extends [infer A] ? P extends Set<any> ? Set<A> : P extends WeakSet<any> ? WeakSet<A & object> : P : P;
type WrappedCtorStatics<T> = Pick<T, Exclude<keyof T, "prototype">>;
type WrappedCtor<T, Params extends unknown[], New extends abstract new (...a: any) => any> = New & WrappedCtorStatics<T> & {
    prototype: Wrapped<InstantiatePrototype<ConstructorPrototype<T>, Params>>;
    readonly [WrappedBrand]: T;
};
type WrappedConstructor<T> = T extends MapConstructor ? WrappedCtor<T, [
    unknown,
    unknown
], new <K, V>(entries?: Iterable<readonly [K, V]> | null) => Wrapped<Map<K, V>>> : T extends SetConstructor ? WrappedCtor<T, [
    unknown
], new <U>(values?: Iterable<U> | null) => Wrapped<Set<U>>> : T extends WeakMapConstructor ? WrappedCtor<T, [
    WeakKey,
    unknown
], new <K extends WeakKey, V>(entries?: Iterable<readonly [K, V]> | null) => Wrapped<WeakMap<K, V>>> : T extends WeakSetConstructor ? WrappedCtor<T, [
    object
], new <U extends object>(values?: Iterable<U> | null) => Wrapped<WeakSet<U>>> : T extends abstract new (...args: infer Args) => infer Instance ? Omit<T, "prototype"> & {
    new (...args: Args): WrappedInstance<Instance>;
    prototype: WrappedInstance<Instance>;
    readonly [WrappedBrand]: T;
} : never;
export type Wrapped<T> = T extends abstract new (...args: any) => any ? WrappedConstructor<T> : T & {
    readonly [WrappedBrand]: T;
};
export declare const _URL: Omit<{
    new (url: string | URL, base?: string | URL): URL;
    prototype: URL;
    canParse(url: string | URL, base?: string | URL): boolean;
    createObjectURL(obj: Blob | MediaSource): string;
    parse(url: string | URL, base?: string | URL): URL | null;
    revokeObjectURL(url: string): void;
}, "prototype"> & {
    new (url: string | URL, base?: string | URL): URL & {
        readonly [WrappedBrand]: URL;
    };
    prototype: URL & {
        readonly [WrappedBrand]: URL;
    };
    readonly [WrappedBrand]: {
        new (url: string | URL, base?: string | URL): URL;
        prototype: URL;
        canParse(url: string | URL, base?: string | URL): boolean;
        createObjectURL(obj: Blob | MediaSource): string;
        parse(url: string | URL, base?: string | URL): URL | null;
        revokeObjectURL(url: string): void;
    };
};
export type _URL = Wrapped<URL>;
export declare const _Headers: Omit<{
    new (init?: HeadersInit): Headers;
    prototype: Headers;
}, "prototype"> & {
    new (init?: HeadersInit): Headers & {
        readonly [WrappedBrand]: Headers;
    };
    prototype: Headers & {
        readonly [WrappedBrand]: Headers;
    };
    readonly [WrappedBrand]: {
        new (init?: HeadersInit): Headers;
        prototype: Headers;
    };
};
export type _Headers = Wrapped<Headers>;
export declare const _Date: Omit<DateConstructor, "prototype"> & {
    new (value: string | number | Date): Date & {
        readonly [WrappedBrand]: Date;
    };
    prototype: Date & {
        readonly [WrappedBrand]: Date;
    };
    readonly [WrappedBrand]: DateConstructor;
};
export type _Date = Wrapped<Date>;
export declare const _URLSearchParams: Omit<{
    new (init?: string[][] | Record<string, string> | string | URLSearchParams): URLSearchParams;
    prototype: URLSearchParams;
}, "prototype"> & {
    new (init?: string | Record<string, string> | URLSearchParams | string[][]): URLSearchParams & {
        readonly [WrappedBrand]: URLSearchParams;
    };
    prototype: URLSearchParams & {
        readonly [WrappedBrand]: URLSearchParams;
    };
    readonly [WrappedBrand]: {
        new (init?: string[][] | Record<string, string> | string | URLSearchParams): URLSearchParams;
        prototype: URLSearchParams;
    };
};
export type _URLSearchParams = Wrapped<URLSearchParams>;
export declare const _RegExp: Omit<RegExpConstructor, "prototype"> & {
    new (pattern: string | RegExp, flags?: string): RegExp & {
        readonly [WrappedBrand]: RegExp;
    };
    prototype: RegExp & {
        readonly [WrappedBrand]: RegExp;
    };
    readonly [WrappedBrand]: RegExpConstructor;
};
export type _RegExp = Wrapped<RegExp>;
export declare const _Set: WrappedCtor<SetConstructor, [unknown], new <U>(values?: Iterable<U> | null) => Wrapped<Set<U>>>;
export type _Set<T> = Wrapped<Set<T>>;
export declare const _Map: WrappedCtor<MapConstructor, [unknown, unknown], new <K, V>(entries?: Iterable<readonly [K, V]> | null) => Wrapped<Map<K, V>>>;
export type _Map<K, V> = Wrapped<Map<K, V>>;
export declare const _WeakSet: WrappedCtor<WeakSetConstructor, [object], new <U extends object>(values?: Iterable<U> | null) => Wrapped<WeakSet<U>>>;
export type _WeakSet<T extends object> = Wrapped<WeakSet<T>>;
export declare const _WeakMap: WrappedCtor<WeakMapConstructor, [WeakKey, unknown], new <K extends WeakKey, V>(entries?: Iterable<readonly [K, V]> | null) => Wrapped<WeakMap<K, V>>>;
export type _WeakMap<K extends object, V extends object> = Wrapped<WeakMap<K, V>>;
export declare const _Uint8Array: Omit<Uint8ArrayConstructor, "prototype"> & {
    new (): Uint8Array<ArrayBuffer> & {
        readonly [WrappedBrand]: Uint8Array<ArrayBuffer>;
    };
    prototype: Uint8Array<ArrayBuffer> & {
        readonly [WrappedBrand]: Uint8Array<ArrayBuffer>;
    };
    readonly [WrappedBrand]: Uint8ArrayConstructor;
};
export type _Uint8Array = Wrapped<Uint8Array>;
export declare const _TextDecoder: Omit<{
    new (label?: string, options?: TextDecoderOptions): TextDecoder;
    prototype: TextDecoder;
}, "prototype"> & {
    new (label?: string, options?: TextDecoderOptions): TextDecoder & {
        readonly [WrappedBrand]: TextDecoder;
    };
    prototype: TextDecoder & {
        readonly [WrappedBrand]: TextDecoder;
    };
    readonly [WrappedBrand]: {
        new (label?: string, options?: TextDecoderOptions): TextDecoder;
        prototype: TextDecoder;
    };
};
export type _TextDecoder = Wrapped<TextDecoder>;
export declare const _TextEncoder: Omit<{
    new (): TextEncoder;
    prototype: TextEncoder;
}, "prototype"> & {
    new (): TextEncoder & {
        readonly [WrappedBrand]: TextEncoder;
    };
    prototype: TextEncoder & {
        readonly [WrappedBrand]: TextEncoder;
    };
    readonly [WrappedBrand]: {
        new (): TextEncoder;
        prototype: TextEncoder;
    };
};
export type _TextEncoder = Wrapped<TextEncoder>;
export declare function makeWrap<T extends object>(source: T): Wrapped<T>;
export declare const CapturedGlobal: typeof globalThis;
export declare const ArrayBuffer_isView: (arg: any) => arg is ArrayBufferView;
export declare const NativeArray: ArrayConstructor;
export declare const NativeArrayBuffer: ArrayBufferConstructor;
export declare const NativeBlob: {
    new (blobParts?: BlobPart[], options?: BlobPropertyBag): Blob;
    prototype: Blob;
};
export declare const NativeDataView: DataViewConstructor;
export declare const NativeDate: DateConstructor;
export declare const NativeError: ErrorConstructor;
export declare const NativeHeaders: {
    new (init?: HeadersInit): Headers;
    prototype: Headers;
};
export declare const NativeMap: MapConstructor;
export declare const NativeNumber: NumberConstructor;
export declare const NativeObject: ObjectConstructor;
export declare const NativePromise: PromiseConstructor;
export declare const NativeReadableStream: {
    new (underlyingSource: UnderlyingByteSource, strategy?: {
        highWaterMark?: number;
    }): ReadableStream<Uint8Array<ArrayBuffer>>;
    new <R = any>(underlyingSource: UnderlyingDefaultSource<R>, strategy?: QueuingStrategy<R>): ReadableStream<R>;
    new <R = any>(underlyingSource?: UnderlyingSource<R>, strategy?: QueuingStrategy<R>): ReadableStream<R>;
    prototype: ReadableStream;
};
export declare const NativeResponse: {
    new (body?: BodyInit | null, init?: ResponseInit): Response;
    prototype: Response;
    error(): Response;
    json(data: any, init?: ResponseInit): Response;
    redirect(url: string | URL, status?: number): Response;
};
export declare const NativeRequest: {
    new (input: RequestInfo | URL, init?: RequestInit): Request;
    prototype: Request;
};
export declare const NativeReflect: typeof Reflect;
export declare const NativeRegExp: RegExpConstructor;
export declare const NativeSharedArrayBuffer: SharedArrayBufferConstructor;
export declare const NativeSymbol: SymbolConstructor;
export declare const NativeTextDecoder: {
    new (label?: string, options?: TextDecoderOptions): TextDecoder;
    prototype: TextDecoder;
};
export declare const NativeTextEncoder: {
    new (): TextEncoder;
    prototype: TextEncoder;
};
export declare const NativeURL: {
    new (url: string | URL, base?: string | URL): URL;
    prototype: URL;
    canParse(url: string | URL, base?: string | URL): boolean;
    createObjectURL(obj: Blob | MediaSource): string;
    parse(url: string | URL, base?: string | URL): URL | null;
    revokeObjectURL(url: string): void;
};
export declare const NativeUint8Array: Uint8ArrayConstructor;
export declare const NativeWeakMap: WeakMapConstructor;
export declare const NativeWeakSet: WeakSetConstructor;
export declare const NativeWebAssembly: typeof WebAssembly;
export declare const NativeWritableStream: {
    new <W = any>(underlyingSink?: UnderlyingSink<W>, strategy?: QueuingStrategy<W>): WritableStream<W>;
    prototype: WritableStream;
};
export declare const Nativeconsole: Console;
export declare const Nativeperformance: Performance;
export {};
