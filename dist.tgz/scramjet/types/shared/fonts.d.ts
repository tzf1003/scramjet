export declare const emojiFamily = "Scramjet Twemoji 14";
export declare const missingFamily = "Scramjet Unavailable Font";
/** Includes localized, PostScript and common vendor aliases. */
export declare function isRestrictedFont(name: string): boolean;
/** Preserve the caller's fallback order after the fixed emoji face. */
export declare function rewriteFontValue(value: string, property?: string, emoji?: boolean): string;
export declare function rewriteFontSource(source: string): string;
/** Parse declarations so selectors, content strings and URLs remain intact. */
export declare function rewriteFontCss(css: string): string;
