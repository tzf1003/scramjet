import type { ScramjetEnvironmentConfig } from "../types";
/** Validate before navigation so a malformed profile cannot silently fall back. */
export declare function normalizeEnvironment(config?: ScramjetEnvironmentConfig): ScramjetEnvironmentConfig;
export declare function environmentAcceptLanguage(config?: ScramjetEnvironmentConfig): string | undefined;
