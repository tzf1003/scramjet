/**
 * WebRTC policy helpers shared by the controller (credential prefetch) and the
 * client hook. This file must stay free of browser-only side effects so it can be
 * unit tested with Node's type stripping.
 */
export type WebrtcMode = "off" | "relay" | "enforced";
export type WebrtcIceServer = {
    urls: string | string[];
    username?: string;
    credential?: string;
};
export type ScramjetWebrtcConfig = {
    /** off: leave native WebRTC alone. relay/enforced: force TURN relay. */
    mode: WebrtcMode;
    /** Authorised TURN servers. Replaced/resolved by the trusted controller. */
    iceServers: WebrtcIceServer[];
    /** Same-origin endpoint that issues coturn REST credentials. */
    credentialEndpoint: string | null;
    /** Epoch ms when iceServers expire; null for static credentials. */
    iceServersExpiresAt: number | null;
    /** Refresh credentials at ttl * ratio (0.1..0.95). */
    credentialRefreshRatio: number;
    /** Throw on PeerConnection creation when no valid credentials exist. */
    failClosed: boolean;
    /** Log policy decisions (never credentials) for debugging. */
    diagnostics: boolean;
    /**
     * Deployment attestation that the network layer blocks non-TURN egress.
     * Required for enforced mode; the client cannot verify the kernel itself.
     */
    networkIsolationVerified: boolean;
};
export declare const defaultWebrtcConfig: ScramjetWebrtcConfig;
export declare function isTurnUrl(url: string): boolean;
export declare function cloneIceServers(servers: readonly WebrtcIceServer[]): WebrtcIceServer[];
/**
 * Validate and clone a controller-provided WebRTC policy. Unknown/invalid values
 * throw: a mistyped policy must not silently degrade to direct ICE.
 */
export declare function normalizeWebrtcConfig(input: Partial<ScramjetWebrtcConfig> | null | undefined): ScramjetWebrtcConfig;
/** Clone and freeze the policy inherited by later injected realms. */
export declare function snapshotWebrtcConfig(input: Partial<ScramjetWebrtcConfig> | null | undefined): ScramjetWebrtcConfig;
/**
 * Build a native RTCConfiguration from a page-supplied config. Only non-network
 * fields survive; ICE servers and policy always come from the trusted policy.
 */
export declare function sanitizeRtcConfiguration(input: unknown, servers: readonly WebrtcIceServer[], defaults?: RTCConfiguration): RTCConfiguration;
export type CandidateType = "host" | "srflx" | "prflx" | "relay" | "unknown";
/** Extract every ICE candidate type from an SDP body. */
export declare function sdpCandidateTypes(sdp: string): CandidateType[];
/** True when the SDP contains a candidate that did not come from TURN. */
export declare function hasNonRelayCandidates(sdp: string): boolean;
export type WebRtcCredentialPayload = {
    urls?: string | string[];
    username?: string;
    credential?: string;
    ttl?: number;
    iceServers?: unknown;
};
export type ParsedWebrtcCredentials = {
    iceServers: WebrtcIceServer[];
    ttlMs: number;
    expiresAt: number;
};
/**
 * Parse a credential endpoint response. Accepts either
 * `{urls, username, credential, ttl}` or `{iceServers: [...], ttl}`.
 * `ttl` is seconds and must be positive.
 */
export declare function parseWebrtcCredentialPayload(payload: unknown, now: number): ParsedWebrtcCredentials;
export type SelectedCandidatePair = {
    localType: CandidateType | null;
    remoteType: CandidateType | null;
    localAddress: string | null;
    remoteAddress: string | null;
    localPort: number | null;
    remotePort: number | null;
    localProtocol: string | null;
    localRelatedAddress: string | null;
    localRelatedPort: number | null;
    localUrl: string | null;
    localRelayProtocol: string | null;
    state: string | null;
    nominated: boolean | null;
    selected: boolean | null;
};
type StatsLike = {
    forEach(callback: (stat: Record<string, any>, id: string) => void): void;
};
/** Return every selected transport; incomplete references remain observable. */
export declare function evaluateSelectedCandidatePairs(report: StatsLike): SelectedCandidatePair[];
/** Compatibility helper for callers that inspect a single bundled transport. */
export declare function evaluateSelectedCandidatePair(report: StatsLike): SelectedCandidatePair | null;
export {};
