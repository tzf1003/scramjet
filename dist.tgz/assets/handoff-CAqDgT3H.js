import{r as o,n as a}from"./handoff-0GQ2Gv9L.js";o(new URL(location.href),a("xs2api.com"));
