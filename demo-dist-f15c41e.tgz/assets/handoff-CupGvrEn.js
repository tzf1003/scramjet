import{r as o,n as a}from"./handoff-Bl848qP1.js";o(new URL(location.href),a("xs2api.com"));
